package com.afrocityrp.launcher

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.SystemClock
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

class MainActivity : Activity() {
    private val serverHost = "142.132.203.47"
    private val serverPort = 14585
    private val serverAddress = "$serverHost:$serverPort"
    // HTTPS JSON endpoint returning [{"title","date","summary","url"}]. Leave empty until you host one.
    private val newsUrl = "https://liveafricanroleplay-dot.github.io/afro-city-api/news.json"
    // HTTPS JSON endpoint listing your server's custom files:
    // [{"path":"models/skin1.dff","url":"https://...","sha256":"<hex>","size":12345}]
    private val filesManifestUrl = "https://liveafricanroleplay-dot.github.io/afro-city-api/files.json"
    private var downloading = false
    private val prefs by lazy { getSharedPreferences("afro_prefs", Context.MODE_PRIVATE) }
    private val green = Color.rgb(64, 200, 110)
    private val discordUrl = "https://discord.gg/CypzN9TS9q"
    private val bg = Color.rgb(8, 8, 10)
    private val panel = Color.rgb(22, 22, 27)
    private val red = Color.rgb(224, 28, 50)
    private val white = Color.rgb(248, 248, 250)
    private val muted = Color.rgb(169, 171, 181)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showHome()
    }

    private fun shell(title: String, subtitle: String): LinearLayout {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(26))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(8, 8, 10), Color.rgb(30, 8, 14), Color.rgb(8, 8, 10))
            )
        }
        scroll.addView(root)
        setContentView(scroll)
        val brand = TextView(this).apply {
            text = "♛  AFRO CITY RP"
            textSize = 27f
            setTextColor(white)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = 0.04f
        }
        root.addView(brand, matchWrap())
        root.addView(label("SERIOUS ROLEPLAY  •  OFFICIAL LAUNCHER", 11, red, true).apply {
            gravity = Gravity.CENTER
        })
        root.addView(space(24))
        root.addView(label(title, 25, white, true))
        root.addView(label(subtitle, 14, muted, false))
        root.addView(space(18))
        return root
    }

    private fun showHome() {
        shell("YOUR CITY. YOUR STORY.", "Enter a serious roleplay community built around your character.")
        val hero = card()
        hero.addView(label("AFRO CITY", 30, white, true))
        hero.addView(label("A new life is waiting.", 17, red, true))
        hero.addView(label("Build your reputation, meet the community, and make your own story. The game world is being prepared separately.", 14, muted, false))
        root.addView(hero, matchWrap())
        root.addView(space(14))
        root.addView(primaryButton("▶   PLAY NOW") { showPlayDialog() }, matchWrap())
        root.addView(space(10))
        root.addView(actionButton("SETUP GUIDE") { showSetup() }, matchWrap())
        root.addView(space(10))
        root.addView(actionButton("GAME FILES") { showFiles() }, matchWrap())
        root.addView(space(10))
        root.addView(actionButton("SERVER INFORMATION") { showServer() }, matchWrap())
        root.addView(space(10))
        root.addView(actionButton("PLAYER ACCOUNT") { showAccount() }, matchWrap())
        root.addView(space(10))
        root.addView(actionButton("NEWS") { showNews() }, matchWrap())
        root.addView(space(10))
        root.addView(actionButton("SUPPORT  •  DISCORD") { showCommunity() }, matchWrap())
        root.addView(space(10))
        root.addView(actionButton("SETTINGS") { showSettings() }, matchWrap())
        root.addView(space(20))
        val status = card()
        status.addView(label("SERVER STATUS", 12, muted, true))
        status.addView(label(serverAddress, 18, red, true))
        val live = label("Checking server…", 14, muted, false)
        status.addView(live)
        status.addView(actionButton("REFRESH STATUS") { loadStatus(live) })
        status.addView(actionButton("COPY SERVER ADDRESS") { copyServerAddress() })
        if (prefs.getBoolean("auto_status", true)) loadStatus(live) else live.text = "Auto-check is off. Tap refresh."
        root.addView(status, matchWrap())
        root.addView(space(20))
        root.addView(label("AFRO CITY RP  •  LAUNCHER ${versionName()}", 11, muted, false).apply { gravity = Gravity.CENTER })
    }

    private fun showServer() {
        shell("SERVER INFORMATION", "Your connection details in one place.")
        val c = card()
        c.addView(label("AFRO CITY RP", 22, white, true))
        c.addView(label(serverAddress, 18, red, true))
        c.addView(label("Game: SA-MP / open.mp compatible client required\nRegion: Germany (hosting configuration previously provided)", 14, muted, false))
        val live = label("Checking server…", 14, muted, false)
        c.addView(live)
        loadStatus(live)
        c.addView(actionButton("REFRESH STATUS") { loadStatus(live) })
        c.addView(primaryButton("COPY SERVER ADDRESS") { copyServerAddress() })
        c.addView(actionButton("HOW TO CONNECT") { showPlayDialog() })
        root.addView(c, matchWrap())
        addBack()
    }

    private fun showAccount() {
        shell("PLAYER ACCOUNT", "Account services are being integrated.")
        val c = card()
        c.addView(label("Sign-in is not active yet", 19, white, true))
        c.addView(label("The launcher is not connected to the AFRO CITY RP account database. Do not enter your real game password here. These fields are a design preview only.", 14, muted, false))
        val username = EditText(this).apply {
            hint = "Player name"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = inputBackground()
        }
        c.addView(username, matchWrap())
        c.addView(space(8))
        val password = EditText(this).apply {
            hint = "Password (preview only)"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            inputType = 129
            setSingleLine(true)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = inputBackground()
        }
        c.addView(password, matchWrap())
        c.addView(space(10))
        c.addView(primaryButton("SIGN IN  •  NOT CONNECTED") {
            password.text?.clear()
            Toast.makeText(this, "Account authentication has not been connected. No password was sent.", Toast.LENGTH_LONG).show()
        })
        c.addView(actionButton("REGISTER") {
            password.text?.clear()
            AlertDialog.Builder(this)
                .setTitle("Registration not available yet")
                .setMessage("Registration will be enabled after a secure server authentication API is connected.")
                .setPositiveButton("OK", null).show()
        })
        root.addView(c, matchWrap())
        addBack()
    }

    private fun showCommunity() {
        shell("COMMUNITY", "Stay connected with AFRO CITY RP.")
        val c = card()
        c.addView(label("DISCORD COMMUNITY", 18, white, true))
        c.addView(label("Join the community for updates and support.", 14, muted, false))
        c.addView(primaryButton("OPEN DISCORD") {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(discordUrl))) }
            catch (_: Exception) { Toast.makeText(this, "Could not open Discord link.", Toast.LENGTH_LONG).show() }
        })
        c.addView(actionButton("COPY DISCORD INVITE") {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("AFRO CITY RP Discord", discordUrl))
            Toast.makeText(this, "Discord invite copied.", Toast.LENGTH_SHORT).show()
        })
        c.addView(actionButton("VIEW NEWS") { showNews() })
        root.addView(c, matchWrap())
        addBack()
    }

    private fun showSettings() {
        shell("SETTINGS", "Simple launcher preferences.")
        val c = card()
        c.addView(label("PLAYER NICKNAME", 17, white, true))
        c.addView(label("3–20 characters: letters, numbers and _ [ ] $ = @ . ( ) only. Stored on this device only.", 13, muted, false))
        val nick = EditText(this).apply {
            hint = "Nickname"
            setText(savedNickname())
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = inputBackground()
        }
        c.addView(nick, matchWrap())
        c.addView(primaryButton("SAVE NICKNAME") {
            val value = nick.text.toString().trim()
            if (isValidNickname(value)) {
                prefs.edit().putString("nickname", value).apply()
                Toast.makeText(this, "Nickname saved.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Invalid nickname. Use 3–20 allowed characters.", Toast.LENGTH_LONG).show()
            }
        })
        c.addView(actionButton("COPY NICKNAME") {
            val v = savedNickname()
            if (v.isEmpty()) Toast.makeText(this, "Save a nickname first.", Toast.LENGTH_SHORT).show()
            else copyText("AFRO CITY RP nickname", v, "Nickname copied.")
        })
        c.addView(space(10))
        c.addView(label("SERVER STATUS", 17, white, true))
        val autoOn = prefs.getBoolean("auto_status", true)
        val toggle = actionButton(if (autoOn) "AUTO-CHECK ON OPEN: ON" else "AUTO-CHECK ON OPEN: OFF") {}
        toggle.setOnClickListener {
            val now = !prefs.getBoolean("auto_status", true)
            prefs.edit().putBoolean("auto_status", now).apply()
            toggle.text = if (now) "AUTO-CHECK ON OPEN: ON" else "AUTO-CHECK ON OPEN: OFF"
        }
        c.addView(toggle)
        c.addView(space(10))
        c.addView(label("APP VERSION", 17, white, true))
        c.addView(label("AFRO CITY RP Launcher ${versionName()} (development build)", 14, muted, false))
        c.addView(label("GAME CLIENT", 17, white, true))
        c.addView(label("A compatible Android multiplayer client is required. This launcher does not contain GTA game files.", 14, muted, false))
        root.addView(c, matchWrap())
        addBack()
    }

    private fun showNews() {
        shell("NEWS", "Latest from AFRO CITY RP.")
        val c = card()
        val state = label("Loading news…", 14, muted, false)
        c.addView(state)
        root.addView(c, matchWrap())
        addBack()
        if (newsUrl.isBlank()) {
            state.text = "The news feed has not been configured yet. Set newsUrl to an HTTPS JSON endpoint."
            return
        }
        Thread {
            val items = try { fetchNews() } catch (_: Exception) { null }
            runOnUiThread {
                if (!state.isAttachedToWindow) return@runOnUiThread
                if (items == null) { state.text = "Could not load news. Check your connection and try again."; return@runOnUiThread }
                if (items.isEmpty()) { state.text = "No news yet."; return@runOnUiThread }
                c.removeView(state)
                items.forEach { n ->
                    c.addView(label(n.title, 17, white, true))
                    if (n.date.isNotEmpty()) c.addView(label(n.date, 11, red, true))
                    if (n.summary.isNotEmpty()) c.addView(label(n.summary, 14, muted, false))
                    if (n.url.startsWith("https://")) c.addView(actionButton("READ MORE") {
                        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.url))) }
                        catch (_: Exception) { Toast.makeText(this, "Could not open link.", Toast.LENGTH_LONG).show() }
                    })
                    c.addView(space(10))
                }
            }
        }.start()
    }

    private fun showPlayDialog() {
        AlertDialog.Builder(this)
            .setTitle("Play AFRO CITY RP")
            .setMessage("Server address:\n$serverAddress\nNickname: ${savedNickname().ifEmpty { "not set (see Settings)" }}\n\nTap TRY GAME CLIENT to open a compatible multiplayer app if it supports the samp:// link. If nothing opens, copy the address and add it inside your multiplayer client. This launcher does not include GTA files.")
            .setPositiveButton("TRY GAME CLIENT") { _, _ -> launchGameClient() }
            .setNeutralButton("COPY ADDRESS") { _, _ -> copyServerAddress() }
            .setNegativeButton("CLOSE", null)
            .show()
    }

    private fun findClients(): Int = try {
        packageManager.queryIntentActivities(Intent(Intent.ACTION_VIEW, Uri.parse("samp://$serverAddress")), 0).size
    } catch (_: Exception) { 0 }

    private fun launchGameClient() {
        if (findClients() == 0) {
            AlertDialog.Builder(this)
                .setTitle("No SA-MP client found")
                .setMessage("Install a compatible SA-MP Android client first. The setup guide walks you through it.")
                .setPositiveButton("SETUP GUIDE") { _, _ -> showSetup() }
                .setNeutralButton("COPY ADDRESS") { _, _ -> copyServerAddress() }
                .setNegativeButton("CLOSE", null)
                .show()
            return
        }
        val nick = savedNickname()
        if (nick.isNotEmpty()) copyText("AFRO CITY RP nickname", nick, "Nickname copied. Paste it in the client if asked.")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("samp://$serverAddress")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            Toast.makeText(this, "Could not open the client. Add $serverAddress inside it manually.", Toast.LENGTH_LONG).show()
            copyServerAddress()
        }
    }

    private fun showSetup() {
        shell("SETUP GUIDE", "Get ready to play in four steps.")
        val c = card()
        val clients = findClients()
        val nick = savedNickname()
        c.addView(label(if (clients > 0) "✓  1. SA-MP client installed" else "✗  1. Install a SA-MP Android client", 16,
            if (clients > 0) green else red, true))
        c.addView(label(if (nick.isNotEmpty()) "✓  2. Nickname saved: $nick" else "✗  2. Save your nickname in Settings", 16,
            if (nick.isNotEmpty()) green else red, true))
        if (nick.isEmpty()) c.addView(actionButton("OPEN SETTINGS") { showSettings() })
        val srv = label("…  3. Checking server", 16, muted, true)
        c.addView(srv)
        c.addView(label("▸  4. Download server files (if your server uses any)", 16, white, true))
        c.addView(actionButton("GAME FILES") { showFiles() })
        c.addView(space(8))
        c.addView(primaryButton("▶   PLAY NOW") { showPlayDialog() })
        root.addView(c, matchWrap())
        addBack()
        Thread {
            val st = queryServer()
            runOnUiThread {
                if (!srv.isAttachedToWindow) return@runOnUiThread
                srv.text = if (st.online) "✓  3. Server online (${st.players}/${st.maxPlayers})" else "✗  3. Server not responding"
                srv.setTextColor(if (st.online) green else red)
            }
        }.start()
    }

    // ---- Server file downloader ----

    private data class RemoteFile(val path: String, val url: String, val sha256: String, val size: Long)

    private fun filesRoot(): File = getExternalFilesDir("server-files") ?: File(filesDir, "server-files")

    private fun showFiles() {
        shell("GAME FILES", "Download and update your server's custom files.")
        val c = card()
        c.addView(label("Saved to:\n${filesRoot().absolutePath}", 12, muted, false))
        val state = label(
            if (filesManifestUrl.isBlank()) "No file list is configured yet. Set filesManifestUrl to an HTTPS JSON endpoint." else "Ready.",
            14, muted, false
        )
        c.addView(state)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = 0 }
        c.addView(bar, matchWrap())
        c.addView(primaryButton("CHECK & DOWNLOAD") {
            if (filesManifestUrl.isBlank()) return@primaryButton
            if (downloading) { Toast.makeText(this, "A download is already running.", Toast.LENGTH_SHORT).show(); return@primaryButton }
            downloading = true
            Thread {
                try {
                    syncFiles(
                        onStatus = { msg -> runOnUiThread { if (state.isAttachedToWindow) state.text = msg } },
                        onProgress = { pct -> runOnUiThread { if (bar.isAttachedToWindow) bar.progress = pct } }
                    )
                } catch (e: Exception) {
                    runOnUiThread { if (state.isAttachedToWindow) state.text = "Download failed: ${e.message ?: "unknown error"}" }
                } finally {
                    downloading = false
                }
            }.start()
        })
        root.addView(c, matchWrap())
        addBack()
    }

    private fun syncFiles(onStatus: (String) -> Unit, onProgress: (Int) -> Unit) {
        onStatus("Checking for updates…")
        val files = httpGet(filesManifestUrl).let { body ->
            val arr = JSONArray(body)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                RemoteFile(o.getString("path"), o.getString("url"), o.getString("sha256").lowercase(), o.optLong("size", 0))
            }
        }
        val root = filesRoot().apply { mkdirs() }
        val rootCanon = root.canonicalPath + File.separator
        val todo = mutableListOf<Pair<RemoteFile, File>>()
        for (f in files) {
            require(Regex("^[A-Za-z0-9._/-]+$").matches(f.path) && !f.path.contains("..")) { "Unsafe file path in list" }
            require(f.url.startsWith("https://")) { "Non-HTTPS download link in list" }
            require(f.sha256.length == 64) { "Missing checksum for ${f.path}" }
            val dest = File(root, f.path)
            require(dest.canonicalPath.startsWith(rootCanon)) { "Unsafe file path in list" }
            if (!(dest.exists() && sha256(dest) == f.sha256)) todo.add(f to dest)
        }
        if (todo.isEmpty()) { onProgress(100); onStatus("Everything is up to date."); return }
        val total = todo.sumOf { it.first.size }.coerceAtLeast(1)
        var done = 0L
        todo.forEachIndexed { idx, (f, dest) ->
            onStatus("Downloading ${idx + 1}/${todo.size}: ${f.path}")
            dest.parentFile?.mkdirs()
            val part = File(dest.path + ".part")
            val conn = URL(f.url).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 10000
                conn.readTimeout = 15000
                if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode} for ${f.path}")
                conn.inputStream.use { input ->
                    part.outputStream().use { out ->
                        val buf = ByteArray(16 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            onProgress(((done * 100) / total).toInt().coerceIn(0, 100))
                        }
                    }
                }
            } finally { conn.disconnect() }
            if (sha256(part) != f.sha256) { part.delete(); throw IllegalStateException("Checksum mismatch for ${f.path}") }
            dest.delete()
            if (!part.renameTo(dest)) throw IllegalStateException("Could not save ${f.path}")
        }
        onProgress(100)
        onStatus("Done. ${todo.size} file(s) downloaded.")
    }

    private fun httpGet(url: String): String {
        require(url.startsWith("https://"))
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText().take(500_000) }
        } finally { conn.disconnect() }
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { i ->
            val buf = ByteArray(16 * 1024)
            while (true) { val n = i.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun addBack() {
        root.addView(space(18))
        root.addView(actionButton("← BACK TO HOME") { showHome() }, matchWrap())
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = GradientDrawable().apply {
            setColor(panel)
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), Color.rgb(62, 31, 39))
        }
    }

    private fun inputBackground() = GradientDrawable().apply {
        setColor(Color.rgb(13, 13, 17))
        cornerRadius = dp(9).toFloat()
        setStroke(dp(1), Color.rgb(77, 37, 45))
    }

    private fun label(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.START
            setPadding(0, dp(4), 0, dp(7))
            setLineSpacing(dp(2).toFloat(), 1f)
        }

    private fun actionButton(title: String, action: () -> Unit) = makeButton(title, false, action)
    private fun primaryButton(title: String, action: () -> Unit) = makeButton(title, true, action)

    private fun makeButton(title: String, primary: Boolean, action: () -> Unit): Button =
        Button(this).apply {
            text = title
            isAllCaps = false
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(white)
            background = GradientDrawable().apply {
                setColor(if (primary) red else Color.rgb(34, 20, 25))
                cornerRadius = dp(11).toFloat()
                if (!primary) setStroke(dp(1), Color.rgb(89, 37, 48))
            }
            setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
            p.topMargin = dp(7)
            layoutParams = p
        }

    private fun copyText(label: String, value: String, toast: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, value))
        Toast.makeText(this, toast, Toast.LENGTH_SHORT).show()
    }

    private fun copyServerAddress() =
        copyText("AFRO CITY RP server", serverAddress, "Server address copied: $serverAddress")

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (_: Exception) { "?" }

    private fun savedNickname(): String = prefs.getString("nickname", "") ?: ""

    private fun isValidNickname(n: String) = Regex("^[A-Za-z0-9_\\[\\]$=@.()]{3,20}$").matches(n)

    // ---- Live server status (SA-MP UDP query, opcode 'i') ----

    private data class ServerStatus(
        val online: Boolean,
        val hostname: String = "",
        val players: Int = 0,
        val maxPlayers: Int = 0,
        val pingMs: Long = 0,
        val passworded: Boolean = false
    )

    private fun loadStatus(target: TextView) {
        target.setTextColor(muted)
        target.text = "Checking server…"
        Thread {
            val st = queryServer()
            runOnUiThread {
                if (!target.isAttachedToWindow) return@runOnUiThread
                if (st.online) {
                    target.setTextColor(green)
                    target.text = "● ONLINE  •  ${st.players}/${st.maxPlayers} players  •  ${st.pingMs} ms" +
                        (if (st.passworded) "  •  🔒" else "") +
                        (if (st.hostname.isNotEmpty()) "\n${st.hostname}" else "")
                } else {
                    target.setTextColor(red)
                    target.text = "● OFFLINE or not responding"
                }
            }
        }.start()
    }

    private fun queryServer(): ServerStatus = try {
        val ip = serverHost.split(".").map { it.toInt() }
        val packet = ByteArray(11)
        "SAMP".toByteArray(Charsets.US_ASCII).copyInto(packet)
        ip.forEachIndexed { i, v -> packet[4 + i] = v.toByte() }
        packet[8] = (serverPort and 0xFF).toByte()
        packet[9] = ((serverPort shr 8) and 0xFF).toByte()
        packet[10] = 'i'.code.toByte()
        DatagramSocket().use { socket ->
            socket.soTimeout = 2500
            val addr = InetAddress.getByName(serverHost)
            val start = SystemClock.elapsedRealtime()
            socket.send(DatagramPacket(packet, packet.size, addr, serverPort))
            val buf = ByteArray(1024)
            val resp = DatagramPacket(buf, buf.size)
            socket.receive(resp)
            val ping = SystemClock.elapsedRealtime() - start
            if (resp.length < 20 || String(buf, 0, 4, Charsets.US_ASCII) != "SAMP") return ServerStatus(false)
            val bb = ByteBuffer.wrap(buf, 0, resp.length).order(ByteOrder.LITTLE_ENDIAN)
            bb.position(11)
            val pass = bb.get().toInt() != 0
            val players = bb.short.toInt() and 0xFFFF
            val max = bb.short.toInt() and 0xFFFF
            val len = bb.int
            val name = if (len in 0..bb.remaining()) {
                val b = ByteArray(len); bb.get(b); String(b, Charsets.ISO_8859_1)
            } else ""
            ServerStatus(true, name, players, max, ping, pass)
        }
    } catch (_: Exception) {
        ServerStatus(false)
    }

    // ---- News ----

    private data class NewsItem(val title: String, val date: String, val summary: String, val url: String)

    private fun fetchNews(): List<NewsItem> {
        require(newsUrl.startsWith("https://"))
        val conn = URL(newsUrl).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            conn.requestMethod = "GET"
            if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode}")
            val body = conn.inputStream.bufferedReader().use { it.readText().take(200_000) }
            val arr = JSONArray(body)
            return (0 until minOf(arr.length(), 20)).map { i ->
                val o = arr.getJSONObject(i)
                NewsItem(o.optString("title"), o.optString("date"), o.optString("summary"), o.optString("url"))
            }.filter { it.title.isNotEmpty() }
        } finally {
            conn.disconnect()
        }
    }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}